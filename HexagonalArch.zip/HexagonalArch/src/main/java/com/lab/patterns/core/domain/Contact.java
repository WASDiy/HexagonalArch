package com.lab.patterns.core.domain;

import java.io.Serializable;

public class Contact implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String name;

	private String numberPhone;

	public Contact() { }

	public Contact(String name, String numberPhone) {
		super();
		this.name = name;
		this.numberPhone = numberPhone;
	}

	public String getName() {
		return name;
	}

	public String getNumberPhone() {
		return numberPhone;
	}
}
