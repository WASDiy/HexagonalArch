package com.lab.patterns.port;

import java.util.List;

import com.lab.patterns.core.domain.Contact;

public interface IContactService {
	
	public void createContact(Contact contact);

	public void deleteContact(String name);
	
	public Contact getContact(String name);
	
	public List<Contact> getAllContacts();

}
