package com.lab.patterns.web;

import java.util.List;

import com.lab.patterns.core.domain.Contact;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public interface IContactRestUI {
	
	@PostMapping("/create")
	void createContact(@RequestBody Contact contact);

	@GetMapping("/{name}")
	public Contact getContact(@PathVariable String name);

	@GetMapping("/delete/{name}")
	public void deleteContact(@PathVariable String name);

	@GetMapping("/getAll")
	public List<Contact> listContact();

}
