package com.lab.patterns.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.lab.patterns.core.domain.Contact;
import com.lab.patterns.port.IContactRepo;

@Repository
public class ContactRepoImpl implements IContactRepo {

	private Map<String, Contact> contactMap = new HashMap<String, Contact>();

	@Override
	public void createContact(Contact contact) {
		contactMap.put(contact.getName(), contact);
	}

	@Override
	public void deleteContact(String name) {
		contactMap.remove(name); }

	@Override
	public Contact getContact(String name) {
		return contactMap.get(name);
	}

	@Override
	public List<Contact> getAllContact() {
		return contactMap.values().stream().collect(Collectors.toList());
	}
}
