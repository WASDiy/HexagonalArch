package com.lab.patterns.port;

import java.util.List;

import com.lab.patterns.core.domain.Contact;

public interface IContactRepo {
	
	void createContact(Contact contact);

	void deleteContact(String name);
	
	Contact getContact(String name);
	
	List<Contact> getAllContact();

}
