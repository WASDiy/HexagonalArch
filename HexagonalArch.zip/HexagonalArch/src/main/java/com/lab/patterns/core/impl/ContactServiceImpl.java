package com.lab.patterns.core.impl;

import java.util.List;

import com.lab.patterns.core.domain.Contact;
import com.lab.patterns.port.IContactRepo;
import com.lab.patterns.port.IContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactServiceImpl implements IContactService {

	@Autowired
	private IContactRepo IContactRepo;

	@Override
	public void createContact(Contact contact) {
		IContactRepo.createContact(contact);
	}

	@Override
	public void deleteContact(String name) {
		IContactRepo.deleteContact(name);
	}

	@Override
	public Contact getContact(String name) {

		return IContactRepo.getContact(name);
	}

	@Override
	public List<Contact> getAllContacts() {
		return IContactRepo.getAllContact();
	}

}
