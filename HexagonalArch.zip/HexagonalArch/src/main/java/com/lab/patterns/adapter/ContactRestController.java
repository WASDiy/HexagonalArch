package com.lab.patterns.adapter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lab.patterns.core.domain.Contact;
import com.lab.patterns.port.IContactService;
import com.lab.patterns.web.IContactRestUI;

@RestController
public class ContactRestController implements IContactRestUI {

	@Autowired
	private IContactService IContactService;

	@Override
	public void createContact(@RequestBody Contact contact) {
		IContactService.createContact(contact);
	}

	@Override
	public void deleteContact(@RequestBody String name) {
		IContactService.deleteContact(name);
	}

	@Override
	public Contact getContact(@PathVariable String name) {
		return IContactService.getContact(name);
	}

	@Override
	public List<Contact> listContact() {
		return IContactService.getAllContacts();
	}
}
