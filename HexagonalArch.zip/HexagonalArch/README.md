Hexagonal Architecture in Java.

Please visit following page to know more :
https://www.technopreneur-milind.com/p/hexagonal-architecture-in-java.html
